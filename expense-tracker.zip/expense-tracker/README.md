# Expense Tracker

Production-ready Next.js + Supabase expense tracker.

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in Supabase SQL Editor.
3. Enable Email auth and configure Google OAuth if desired.
4. Copy `.env.example` to `.env.local` and set Supabase URL + publishable key.
5. `npm install && npm run dev`.
6. Deploy to Vercel and add the same environment variables.

Supabase Auth uses cookie-based SSR via `@supabase/ssr`; database isolation is enforced with PostgreSQL RLS.
