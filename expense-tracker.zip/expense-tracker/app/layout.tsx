import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from 'sonner';
export const metadata={title:'Expense Tracker',description:'Personal finance dashboard'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en" suppressHydrationWarning><body><ThemeProvider><Toaster richColors position="top-right"/>{children}</ThemeProvider></body></html>}
