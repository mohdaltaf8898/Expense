import {createClient} from '@/lib/supabase/server';import {redirect} from 'next/navigation';import {Shell} from '@/components/shell';
export default async function Layout({children}:{children:React.ReactNode}){const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect('/login');return <Shell>{children}</Shell>}
